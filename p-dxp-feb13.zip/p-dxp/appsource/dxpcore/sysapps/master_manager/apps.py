from django.apps import AppConfig


class MasterManagerConfig(AppConfig):
    name = 'master_manager'
