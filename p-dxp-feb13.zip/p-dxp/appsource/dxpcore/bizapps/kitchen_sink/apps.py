from django.apps import AppConfig


class KitchenSinkConfig(AppConfig):
    name = 'kitchen_sink'
