from django.apps import AppConfig


class KsDemoConfig(AppConfig):
    name = 'ks_demo'
