from django.apps import AppConfig


class UiUtilsConfig(AppConfig):
    name = 'ui_utils'
