-- MySQL dump 10.13  Distrib 8.0.23, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add Continent',7,'add_continent'),(26,'Can change Continent',7,'change_continent'),(27,'Can delete Continent',7,'delete_continent'),(28,'Can view Continent',7,'view_continent'),(29,'Can add Country',8,'add_country'),(30,'Can change Country',8,'change_country'),(31,'Can delete Country',8,'delete_country'),(32,'Can view Country',8,'view_country'),(33,'Can add Currency',9,'add_currency'),(34,'Can change Currency',9,'change_currency'),(35,'Can delete Currency',9,'delete_currency'),(36,'Can view Currency',9,'view_currency'),(37,'Can add DateFormat',10,'add_dateformat'),(38,'Can change DateFormat',10,'change_dateformat'),(39,'Can delete DateFormat',10,'delete_dateformat'),(40,'Can view DateFormat',10,'view_dateformat'),(41,'Can add KVMaster',11,'add_kvmaster'),(42,'Can change KVMaster',11,'change_kvmaster'),(43,'Can delete KVMaster',11,'delete_kvmaster'),(44,'Can view KVMaster',11,'view_kvmaster'),(45,'Can add MasterDataRegistry',12,'add_masterdataregistry'),(46,'Can change MasterDataRegistry',12,'change_masterdataregistry'),(47,'Can delete MasterDataRegistry',12,'delete_masterdataregistry'),(48,'Can view MasterDataRegistry',12,'view_masterdataregistry'),(49,'Can add NameFormat',13,'add_nameformat'),(50,'Can change NameFormat',13,'change_nameformat'),(51,'Can delete NameFormat',13,'delete_nameformat'),(52,'Can view NameFormat',13,'view_nameformat'),(53,'Can add TimeFormat',14,'add_timeformat'),(54,'Can change TimeFormat',14,'change_timeformat'),(55,'Can delete TimeFormat',14,'delete_timeformat'),(56,'Can view TimeFormat',14,'view_timeformat'),(57,'Can add State',15,'add_state'),(58,'Can change State',15,'change_state'),(59,'Can delete State',15,'delete_state'),(60,'Can view State',15,'view_state'),(61,'Can add PostalCode',16,'add_postalcode'),(62,'Can change PostalCode',16,'change_postalcode'),(63,'Can delete PostalCode',16,'delete_postalcode'),(64,'Can view PostalCode',16,'view_postalcode'),(65,'Can add CRegion',17,'add_cregion'),(66,'Can change CRegion',17,'change_cregion'),(67,'Can delete CRegion',17,'delete_cregion'),(68,'Can view CRegion',17,'view_cregion'),(69,'Can add City',18,'add_city'),(70,'Can change City',18,'change_city'),(71,'Can delete City',18,'delete_city'),(72,'Can view City',18,'view_city');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(18,'master_manager','city'),(7,'master_manager','continent'),(8,'master_manager','country'),(17,'master_manager','cregion'),(9,'master_manager','currency'),(10,'master_manager','dateformat'),(11,'master_manager','kvmaster'),(12,'master_manager','masterdataregistry'),(13,'master_manager','nameformat'),(16,'master_manager','postalcode'),(15,'master_manager','state'),(14,'master_manager','timeformat'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (1,'contenttypes','0001_initial','2021-02-06 12:10:23.205079'),(2,'auth','0001_initial','2021-02-06 12:10:28.705350'),(3,'admin','0001_initial','2021-02-06 12:10:48.476650'),(4,'admin','0002_logentry_remove_auto_add','2021-02-06 12:10:53.322053'),(5,'admin','0003_logentry_add_action_flag_choices','2021-02-06 12:10:53.475373'),(6,'contenttypes','0002_remove_content_type_name','2021-02-06 12:10:57.340685'),(7,'auth','0002_alter_permission_name_max_length','2021-02-06 12:11:00.233351'),(8,'auth','0003_alter_user_email_max_length','2021-02-06 12:11:00.566463'),(9,'auth','0004_alter_user_username_opts','2021-02-06 12:11:00.747641'),(10,'auth','0005_alter_user_last_login_null','2021-02-06 12:11:02.764338'),(11,'auth','0006_require_contenttypes_0002','2021-02-06 12:11:03.044928'),(12,'auth','0007_alter_validators_add_error_messages','2021-02-06 12:11:03.172806'),(13,'auth','0008_alter_user_username_max_length','2021-02-06 12:11:05.790597'),(14,'auth','0009_alter_user_last_name_max_length','2021-02-06 12:11:08.647976'),(15,'auth','0010_alter_group_name_max_length','2021-02-06 12:11:09.070218'),(16,'auth','0011_update_proxy_permissions','2021-02-06 12:11:09.237923'),(17,'auth','0012_alter_user_first_name_max_length','2021-02-06 12:11:11.724394'),(18,'master_manager','0001_initial','2021-02-06 12:11:25.127226'),(19,'sessions','0001_initial','2021-02-06 12:11:45.234601');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_city`
--

DROP TABLE IF EXISTS `master_manager_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_city` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  `country_id` int NOT NULL,
  `state_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `master_manager_city_country_id_ffa1cdf9_fk_master_ma` (`country_id`),
  KEY `master_manager_city_state_id_89943cce_fk_master_manager_state_id` (`state_id`),
  CONSTRAINT `master_manager_city_country_id_ffa1cdf9_fk_master_ma` FOREIGN KEY (`country_id`) REFERENCES `master_manager_country` (`id`),
  CONSTRAINT `master_manager_city_state_id_89943cce_fk_master_manager_state_id` FOREIGN KEY (`state_id`) REFERENCES `master_manager_state` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_city`
--

LOCK TABLES `master_manager_city` WRITE;
/*!40000 ALTER TABLE `master_manager_city` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_continent`
--

DROP TABLE IF EXISTS `master_manager_continent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_continent` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_continent`
--

LOCK TABLES `master_manager_continent` WRITE;
/*!40000 ALTER TABLE `master_manager_continent` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_continent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_country`
--

DROP TABLE IF EXISTS `master_manager_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_country` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `iso_4217_alpha` varchar(255) NOT NULL,
  `iso_4217_numeric` varchar(255) NOT NULL,
  `iso2` varchar(2) NOT NULL,
  `iso3` varchar(3) NOT NULL,
  `capital_city` varchar(255) NOT NULL,
  `telephone_calling_code` varchar(5) NOT NULL,
  `internet_domain_code` varchar(5) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  `continent_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `master_manager_count_continent_id_22428170_fk_master_ma` (`continent_id`),
  CONSTRAINT `master_manager_count_continent_id_22428170_fk_master_ma` FOREIGN KEY (`continent_id`) REFERENCES `master_manager_continent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_country`
--

LOCK TABLES `master_manager_country` WRITE;
/*!40000 ALTER TABLE `master_manager_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_cregion`
--

DROP TABLE IF EXISTS `master_manager_cregion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_cregion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  `country_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `master_manager_cregi_country_id_2771cf5a_fk_master_ma` (`country_id`),
  KEY `master_manager_cregion_name_77700c1c` (`name`),
  CONSTRAINT `master_manager_cregi_country_id_2771cf5a_fk_master_ma` FOREIGN KEY (`country_id`) REFERENCES `master_manager_country` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_cregion`
--

LOCK TABLES `master_manager_cregion` WRITE;
/*!40000 ALTER TABLE `master_manager_cregion` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_cregion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_currency`
--

DROP TABLE IF EXISTS `master_manager_currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_currency` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `currency_type` varchar(1) NOT NULL,
  `symbol` varchar(10) DEFAULT NULL,
  `iso_4217_alpha` varchar(10) NOT NULL,
  `iso_4217_numeric` int NOT NULL,
  `major_unit_name` varchar(255) DEFAULT NULL,
  `minor_unit_name` varchar(255) DEFAULT NULL,
  `display_format` varchar(255) DEFAULT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_currency`
--

LOCK TABLES `master_manager_currency` WRITE;
/*!40000 ALTER TABLE `master_manager_currency` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_dateformat`
--

DROP TABLE IF EXISTS `master_manager_dateformat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_dateformat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `display_format` varchar(100) NOT NULL,
  `display_pattern` varchar(100) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_dateformat`
--

LOCK TABLES `master_manager_dateformat` WRITE;
/*!40000 ALTER TABLE `master_manager_dateformat` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_dateformat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_kvmaster`
--

DROP TABLE IF EXISTS `master_manager_kvmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_kvmaster` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key_category` varchar(255) NOT NULL,
  `key_code` varchar(255) NOT NULL,
  `key_name` varchar(255) NOT NULL,
  `key_value` varchar(255) NOT NULL,
  `key_desc` varchar(255) DEFAULT NULL,
  `data_loaded_by` varchar(10) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_code` (`key_code`),
  KEY `master_manager_kvmaster_key_category_16a71c46` (`key_category`),
  KEY `master_manager_kvmaster_key_name_eef8aabf` (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_kvmaster`
--

LOCK TABLES `master_manager_kvmaster` WRITE;
/*!40000 ALTER TABLE `master_manager_kvmaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_kvmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_masterdataregistry`
--

DROP TABLE IF EXISTS `master_manager_masterdataregistry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_masterdataregistry` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_name` varchar(255) NOT NULL,
  `app_display_name` varchar(255) DEFAULT NULL,
  `model_name` varchar(255) NOT NULL,
  `model_display_name` varchar(255) DEFAULT NULL,
  `displayable_fields` longtext,
  `form_fields` longtext,
  `sort_by_fields` longtext,
  `is_mc_required` tinyint(1) NOT NULL,
  `is_ui_required` tinyint(1) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `master_manager_masterdataregistry_app_name_d92c88d9` (`app_name`),
  KEY `master_manager_masterdataregistry_model_name_9ea7349c` (`model_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_masterdataregistry`
--

LOCK TABLES `master_manager_masterdataregistry` WRITE;
/*!40000 ALTER TABLE `master_manager_masterdataregistry` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_masterdataregistry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_nameformat`
--

DROP TABLE IF EXISTS `master_manager_nameformat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_nameformat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `display_format` varchar(100) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_nameformat`
--

LOCK TABLES `master_manager_nameformat` WRITE;
/*!40000 ALTER TABLE `master_manager_nameformat` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_nameformat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_postalcode`
--

DROP TABLE IF EXISTS `master_manager_postalcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_postalcode` (
  `id` int NOT NULL AUTO_INCREMENT,
  `postalcode` varchar(255) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  `country_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postalcode` (`postalcode`),
  KEY `master_manager_posta_country_id_e167231e_fk_master_ma` (`country_id`),
  CONSTRAINT `master_manager_posta_country_id_e167231e_fk_master_ma` FOREIGN KEY (`country_id`) REFERENCES `master_manager_country` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_postalcode`
--

LOCK TABLES `master_manager_postalcode` WRITE;
/*!40000 ALTER TABLE `master_manager_postalcode` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_postalcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_state`
--

DROP TABLE IF EXISTS `master_manager_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_state` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  `country_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `master_manager_state_country_id_c37943de_fk_master_ma` (`country_id`),
  CONSTRAINT `master_manager_state_country_id_c37943de_fk_master_ma` FOREIGN KEY (`country_id`) REFERENCES `master_manager_country` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_state`
--

LOCK TABLES `master_manager_state` WRITE;
/*!40000 ALTER TABLE `master_manager_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_manager_timeformat`
--

DROP TABLE IF EXISTS `master_manager_timeformat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_manager_timeformat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `display_format` varchar(100) NOT NULL,
  `display_pattern` varchar(100) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `datamode` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_manager_timeformat`
--

LOCK TABLES `master_manager_timeformat` WRITE;
/*!40000 ALTER TABLE `master_manager_timeformat` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_manager_timeformat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-06  6:20:36
